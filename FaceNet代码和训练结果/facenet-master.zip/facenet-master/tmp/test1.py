print('Hello world')
